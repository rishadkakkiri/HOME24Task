//
//  Urls.swift
//  home24
//
//  Created by Beegains on 25/07/18.
//  Copyright © 2018 Beegains. All rights reserved.
//

import Foundation
struct AppURLS
{
    public static let ArticleLink="https://api-mobile.home24.com/api/v2.0/categories/100/articles?appDomain=1&locale=de_DE&limit=10"

}
